    <!-- Required Js -->
    <script src="{{ asset('admin/js/vendor-all.min.js') }}"></script>
	<script src="{{ asset('admin/plugins/bootstrap/js/bootstrap.min.js') }}"></script>
    
    <script src="{{ asset('admin/js/pcoded.min.js') }}"></script>
    <!-- amchart js -->
    <script src="{{ asset('admin/plugins/amchart/js/amcharts.js') }}"></script>
    <script src="{{ asset('admin/plugins/amchart/js/gauge.js') }}"></script>
    <script src="{{ asset('admin/plugins/amchart/js/serial.js') }}"></script>
    <script src="{{ asset('admin/plugins/amchart/js/light.js') }}"></script>
    <script src="{{ asset('admin/plugins/amchart/js/pie.min.js') }}"></script>
    <script src="{{ asset('admin/plugins/amchart/js/ammap.min.js') }}"></script>
    <script src="{{ asset('admin/plugins/amchart/js/usaLow.js') }}"></script>
    <script src="{{ asset('admin/plugins/amchart/js/radar.js') }}"></script>
    <script src="{{ asset('admin/plugins/amchart/js/worldLow.js') }}"></script>
    <!-- notification Js -->
    <script src="{{ asset('admin/plugins/notification/js/bootstrap-growl.min.js') }}"></script>

    <!-- dashboard-custom js -->
    <script src="{{ asset('admin/js/pages/dashboard-custom.js') }}"></script>