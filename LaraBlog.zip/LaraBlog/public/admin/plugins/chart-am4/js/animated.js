/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([9],{571:function(n,t,a){n.exports=a(572)},572:function(n,t,a){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var i=a(573);window.am4themes_animated=i.a},573:function(n,t,a){"use strict";var i=a(574);a.d(t,"a",function(){return i.a})},574:function(n,t,a){"use strict";var i=a(114),e=a(55),o=a(104),r=a(87),s=a(86),u=a(245),c=a(108);t.a=function(n){n instanceof i.a&&(n.transitionDuration=400),n instanceof e.a&&(n.rangeChangeDuration=800,n.interpolationDuration=800,n.sequencedInterpolation=!1,n instanceof u.a&&(n.sequencedInterpolation=!0)),n instanceof r.a&&(n.animationDuration=400),n instanceof o.a&&(n.animationDuration=800),n instanceof s.a&&(n.defaultState.transitionDuration=800,n.hiddenState.transitionDuration=1e3,n.hiddenState.properties.opacity=1,n.interpolationDuration=1e3),n instanceof c.a&&(n.urlTarget="_self",n.align="left",n.valign="bottom")}}},[571]);
//# sourceMappingURL=animated.js.map