

<?php $__env->startSection('content'); ?>
    
<div class="row">
    <div class="col-lg-12">

        <div class="table-responsive-sm">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nume</th>
                        <th>Email</th>
                        <th>Telefon</th>
                        <th>Adresa</th>
                        <th>Rol</th>
                        <th>Comenzi</th>
                        <th>Acțiuni</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->address); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td><a href="<?php echo e(route('user.orders', ['id'=>$user->id])); ?>"><?php echo e($user->orders->count()); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('users.edit', ['user'=>$user->id ])); ?>"><i class="fas fa-pencil-alt text-primary"></i></a> &nbsp;
                            <a onclick="event.preventDefault(); document.getElementById('user-delete-<?php echo e($user->id); ?>').submit();" href="<?php echo e(route('users.destroy', ['user'=>$user->id ])); ?>"><i class="fas fa-trash-alt text-danger"></i></a>
                                <form action="<?php echo e(route('users.destroy', ['user'=>$user->id ])); ?>" method="POST" id="user-delete-<?php echo e($user->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>
        <ul class="pagination justify-content-center">
            <li><?php echo e($users->links()); ?></li>
        </ul>
    </div>
</div>

<hr>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/users/index.blade.php ENDPATH**/ ?>