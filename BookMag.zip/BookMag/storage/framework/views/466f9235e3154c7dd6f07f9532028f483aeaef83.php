

<?php $__env->startSection('content'); ?>
    
        <!-- start main content -->
        <div class="row">

            <div class="col-lg-12">
 
                <h2>Toate comenzile</h2>

                <div class="row"> 
                    
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-4">
                        
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Numar carti <span style="float: right; font-weight: bolder;"><a href="#" data-toggle="modal" data-target="#modal-detalii-1"><?php echo e($order->books()->count()); ?></a></span></h5>
                                <h5 class="card-title">Pret total <span style="float: right; font-weight: bolder;"><?php echo e($order->total_price); ?></span></h5>
                                <h5 class="card-title">Data <span style="float: right; font-weight: bolder;"><?php echo e($order->created_at); ?></span></h5>
                                <h5 class="card-title">Client <span style="float: right; font-weight: bolder;"><a href="<?php echo e(route('user.orders', ['id'=>$order->user->id])); ?>"><?php echo e($order->user->name); ?></a></span></h5>
                                <hr>
                                <h5 class="card-title">Adresa de livrare</h5>
                                <p class="card-text"><?php echo e($order->user->address); ?></p>
                                <hr>
                                <?php if($order->status == 'pending'): ?>
                                        <h6 class="card-title">Status <span style="float: right; color:brown;"><?php echo e($order->status); ?></span></h6>
                                   <?php else: ?>
                                        <h6 class="card-title">Status <span style="float: right; color:rgba(4, 185, 4, 0.884);"><?php echo e($order->status); ?></span></h6>
                                <?php endif; ?>
                                <hr>
                                <a href="<?php echo e(route('orders.show', ['order'=>$order->id ])); ?>" class="card-link">Finalizeaza</a>
                                <a onclick="event.preventDefault(); document.getElementById('order-delete-<?php echo e($order->id); ?>').submit();" href="<?php echo e(route('orders.destroy', ['order'=>$order->id ])); ?>" class="card-link" style="float: right;">Sterge</a>
                                <form action="<?php echo e(route('orders.destroy', ['order'=>$order->id ])); ?>" method="POST" id="order-delete-<?php echo e($order->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </div>
                        </div>
                        <div class="modal" id="modal-detalii-1">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    
                                    <div class="modal-body">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Nr.</th>
                                                    <th>Carte</th>
                                                    <th>Pret Carte</th>
                                                    <th>Cantitate</th>
                                                    <th>Pret Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php $__currentLoopData = $order->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($item->title); ?></td>
                                                    <td><?php echo e($item->price); ?></td>
                                                    <td><?php echo e($item->pivot->quantity); ?></td>
                                                    <td><?php echo e($item->price * $item->pivot->quantity); ?></td>
                                                </tr>  
    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   
                    


                </div>
            </div>
                <?php echo e($orders->links()); ?>

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/orders.blade.php ENDPATH**/ ?>