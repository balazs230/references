

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">

        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary">Adaugă carte noua</a>

        <br /><br />
        <div class="table-responsive-lg">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Titlu</th>
                        <th>Categorie</th>
                        <th>Author</th>
                        <th>Preț</th>
                        <th>Pagini</th>
                        <th>Publicare</th>
                        <th>Limba</th>
                        <th>Dimensiuni</th>
                        <th>Stoc</th>
                        <th>Reviews</th>
                        <th>Acțiuni</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->category->category_name); ?></td>
                            <td><?php echo e($book->author); ?></td>
                            <td><?php echo e($book->price); ?></td>
                            <td><?php echo e($book->pages); ?></td>
                            <td><?php echo e(date('Y', strtotime($book->publication))); ?></td>
                            <td><?php echo e($book->language); ?></td>
                            <td><?php echo e($book->size); ?></td>
                            <td><?php echo e($book->stock); ?></td>
                            <td><a href="<?php echo e(route('book.reviews', ['id'=>$book->id])); ?>"><?php echo e($book->reviews()->count()); ?></a></td>
                            <td>
                                <a href="<?php echo e(route('books.show', ['book'=>$book->id ])); ?>" target="_blank"><i class="fas fa-eye text-success"></i></a> &nbsp;
                                <a href="<?php echo e(route('books.edit', ['book'=>$book->id ])); ?>"><i class="fas fa-pencil-alt text-primary"></i></a> &nbsp;
                                <a href="<?php echo e(route('book.description', ['book_id'=>$book->id ])); ?>"><i class="fas fa-file-alt text-primary"></i></a> &nbsp;
                                <a onclick="event.preventDefault(); document.getElementById('book-delete-<?php echo e($book->id); ?>').submit();" href="<?php echo e(route('books.destroy', ['book'=>$book->id ])); ?>"><i class="fas fa-trash-alt text-danger"></i></a>
                                <form action="<?php echo e(route('books.destroy', ['book'=>$book->id ])); ?>" method="POST" id="book-delete-<?php echo e($book->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                            </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>

        <hr>

      
        <ul class="pagination justify-content-center">
            <li><?php echo e($books->links()); ?></li>
        </ul>

    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/books/index.blade.php ENDPATH**/ ?>