import { useEffect, useState } from "react";
import axios from "axios";

import MovieCard from "./MovieCard";

import './App.css'
import SearchIcon from './search.svg'

// movie api key: fc14fbce

const API_URL = 'http://www.omdbapi.com?apikey=fc14fbce'

const App = () => {
    const [movies, setMovies] = useState([])
    const [searchTerm, setSearchTerm] = useState('')

    const searchMovies = async (title) => {
        // const axios = require('axios').default
        // const data = await axios(`${API_URL}&s=${title}`)
        const response = await fetch(`${API_URL}&s=${title}`)
        const data = await response.json()

        setMovies(data.Search) // beallitjuk a movies state-et a lehivott adatokra
    }

    // useEffect(() => { // lefut minden reload-nal
    //     searchMovies(searchTerm)
    // }, [])

    return (
        <div className="app">
            <h1>Filmek</h1>

            <div className="search">
                <input type="text"
                    placeholder="Keress ra egy filmre"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)} // ha beirunk valamit, akkor egybol frissiti a searchTerm state-et, igy az input mezo value-jat is!
                />
                <img src={SearchIcon} alt="search"
                    onClick={() => searchMovies(searchTerm)} /> 
            </div>

            {
                movies?.length > 0
                    ? (
                        <div className="container">
                            {movies.map((movie) => ( // a movies state-en vegigmappelunk, es sorra atadjuk mindegyik movie-t prop-kent a MovieCard-nak
                                <MovieCard movie={movie} />
                            ))}
                        </div>
                    ) : (
                        <div className="empty">
                            <h2>Nincs talalat</h2>
                        </div>
                    )
            }
        </div>
    )
}

export default App
