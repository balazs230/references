export default [
    {
        id: 1,
        title: 'Title 1',
        description: 'Description 1',
        price: 100,
        coverImg: 'image 12.png',
        stats: {
            rating: 5.0,
            reviewCount: 6
        },
        location: 'Japan',
        openSpots: 0,
    },
    {
        id: 2,
        title: 'Title 2',
        description: 'Description 2',
        price: 200,
        coverImg: 'mountain-bike 1.png',
        stats: {
            rating: 4.0,
            reviewCount: 7
        },
        location: 'Transylvania',
        openSpots: 3,
    },
    {
        id: 3,
        title: 'Title 3',
        description: 'Description 3',
        price: 300,
        coverImg: 'wedding-photography 1.png',
        stats: {
            rating: 3.0,
            reviewCount: 8
        },
        location: 'online',
        openSpots: 5,
    },
]
