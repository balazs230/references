import React from "react"

const Navbar = (props) => {
  return (

    // <nav>
    //   <h1><i style={{fontSize:'24px'}} className="fa">&#xf0ac;</i> Travel Journal</h1>
    // </nav>

    // <nav>
    //   <img src="./airbnb.png" alt="airbnb" className="nav--logo"/>
    // </nav>

    <nav className={props.darkMode ? 'dark' : 'light'}>
      <img src="./react-logo.png" alt="logo" className="nav--icon"/>
      <h3 className="nav--logo_text">ReactFacts</h3>
      <button style={{ backgroundColor: props.darkMode ? 'white' : 'black', color: props.darkMode ? 'black' : 'white' }} className="toggle--button" onClick={props.toggle}>{props.darkMode ? 'Switch to light mode' : 'Switch to dark mode'}</button>
      <h4 className="nav--title">React Course - Project 1</h4>
    </nav>
  )
}

export default Navbar
