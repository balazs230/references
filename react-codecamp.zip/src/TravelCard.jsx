import React from 'react'

const TravelCard = (props) => {
    return (
        <div className='travel-card'>
            <img src={props.destination.imageUrl} alt="" />
            <div className="info">
                <div className='travel-card-location'>
                    <span><i style={{ fontSize:'16px', color:'orangered'}} className="fa">&#xf041;</i> {props.destination.location}</span>
                    <a href={props.destination.mapslink} target='_blank'>View on Google Maps</a>
                </div>
                <h1>{props.destination.title}</h1>
                <div className="dates">
                    <span>{props.destination.startDate} - {props.destination.endDate}</span>
                </div>
                <p className='desc'>{props.destination.description}</p>
            </div>
        </div>
    )
}

export default TravelCard
