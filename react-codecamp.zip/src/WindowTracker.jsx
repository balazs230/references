import React, { useState, useEffect } from 'react'

const WindowTracker = () => {

    const [width, setWidth] = useState(window.innerWidth)

    useEffect(() => {
        function watchWidth() {
            console.log('setting up')
            setWidth(window.innerWidth)
        }
        window.addEventListener('resize', watchWidth)
        return () => {
            console.log('cleaning up')
            window.removeEventListener('resize', watchWidth)
        }
    }, [])

    return (
        <h1>window width: {width}</h1>
    )
}

export default WindowTracker
