import React from 'react'
import { useState } from 'react';

const Joke = (props) => {
    const [isShown, setIsShown] = useState(false);

    function toggleShown() {
        console.log(isShown)
        setIsShown(prevShown => !prevShown)
    }

  return (
    <div>
        {props.setup && <h3>{props.setup}</h3>}
        <p>{props.punchline}</p>
        <button onClick={toggleShown}>Show punchline</button>
        <hr />
    </div>
  )
}

export default Joke
