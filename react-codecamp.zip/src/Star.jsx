import React from 'react'

const Star = (props) => {
  let starIcon = props.isFilled ? `./star-filled.png` : `./star-empty.png`
  return (
    <img src={starIcon}  style={{width:'50px'}} alt="" onClick={props.handleClick}/>
  )
}

export default Star
