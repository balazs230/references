import React from 'react'
import { useState } from 'react'

const Head = ({user}) => {
  return (
    <header>
        <p>Current user: {user}</p>
    </header>
  )
}

export default Head
