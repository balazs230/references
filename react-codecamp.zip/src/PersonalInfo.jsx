import React from 'react'
import Button from './Button'

const PersonalInfo = () => {
  return (
    <div>
        <img src="./aladar.jpg" alt="profile" />
        <h1>Mezga Aladar</h1>
        <h3 style={{color:'orangered'}}>"2 forintert megmondom"</h3>
        <p>raketamernok | szoftverfejleszto | polihisztor</p>
        <Button color={'blue'} text={'LinkedIn'}/>
        <Button color={'gray'} text={'Github'}/>
    </div>
  )
}

export default PersonalInfo
