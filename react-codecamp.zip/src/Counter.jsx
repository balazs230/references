import React, { useState } from 'react'
import Count from './Count';

const Counter = () => {
    const [count, setCount] = useState(0);

    // callback function-t adunk meg a state valtoztato fuggvenynek, ami hozzafer a state korabbi allapotahoz,
    // igy meg lehet hatarozni az alapjan a state uj erteket. se ez mind egy uj fuggvenyben van benne, amit az eventnel meghivunk!
    function add() {
        setCount(function (prevCount) {
            return prevCount + 10 
        })
    }

    function subtract() {
        setCount(function (prevCount) {
            return prevCount - 10
        })
    }

    return (
        <div className='counter'>
            <button className="counter--minus" onClick={subtract}>-</button>
            <Count number={count}/>
            <button className="counter--plus" onClick={add}>+</button>
        </div>
    )
}

export default Counter
