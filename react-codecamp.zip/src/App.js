import './style.css';
import { nanoid } from 'nanoid';
import Navbar from './Navbar'
import Hero from './Hero'
import Card from './Card';
import data from './data';
import TravelCard from './TravelCard';
import travelData from './travel.data';
import Header from './Header';
import Meme from './Meme';
import Counter from './Counter';
import { useState, useEffect } from 'react'
import Star from './Star';
import Head from './Head';
import Body from './Body';
import Box from './Box';
import boxes from './boxes';
import Joke from './Joke';
import Form from './Form';
import WindowTracker from './WindowTracker';
import MainContent from './MainContent';
import Die from './Die';
import Confetti from 'react-confetti'

function App() {

  const [dice, setDice] = useState(allNewDice())
  
  const [tenzies, setTenzies] = useState(false)

  const [rolls, setRolls] = useState(1)

  function reset() {
    setDice(allNewDice())
    setTenzies(false)
    setRolls(1)
    if(rolls < window.localStorage.getItem('tenzies_best') || !window.localStorage.getItem('tenzies_best')) {
      window.localStorage.setItem('tenzies_best', rolls)
    }
  }
  
  useEffect(() => {
    const allHeld = dice.every(die => die.isHeld)
    const firstValue = dice[0].value
    const allSameValue = dice.every(die => die.value === firstValue)
    if (allHeld && allSameValue) {
      setTenzies(true)
    }
  }, [dice])
  
  function generateNewDie() {
    return {
      value: Math.ceil(Math.random() * 6),
      isHeld: false,
      id: nanoid()
    }
  }

  function allNewDice() {
    const newDice = []
    for (let i = 0; i < 10; i++) {
      newDice.push(generateNewDie())
    }
    
    return newDice
  }

  function roll() {
    setRolls(prevRolls => prevRolls + 1)
    setDice(prevDice => prevDice.map(die => {
      return die.isHeld
      ? die
      : generateNewDie()
    }))
  }

  function holdDice(id) {
    setDice(prevDice => prevDice.map(die => {
      return die.id === id
      ? { ...die, isHeld: !die.isHeld }
        : die
    }))
  }

  const diceElements = dice.map(
    die =>
      <Die
        key={die.id}
        value={die.value}
        isHeld={die.isHeld}
        holdDice={() => holdDice(die.id)}
      />
  )

  return (
    <main className='dice-container'>
    {tenzies && <Confetti />}
      <h2 className='title'>Tenzies</h2>
      <h4>Roll until all dice are the same. Click each die to freeze it at its current value between rolls.</h4>
      <div className="squares">
        {diceElements}
      </div>
      <h3>Current game: {rolls} roll{rolls !== 1 && 's'}</h3>
      <h3>Best: {window.localStorage.getItem('tenzies_best')} rolls</h3>
      <button className='dice-btn' onClick={tenzies ? reset : roll}>{tenzies ? 'New game' : 'Roll'}</button>
    </main>
  )
}

export default App;
