import PropTypes from 'prop-types'

const Button = ({ color, text, onClick }) => {
    return (
    <button 
        onClick={onClick}
        style={{backgroundColor: color, borderRadius: 10, width: '100px', height:'50px', margin: '30px'}} 
        className='btn'>
        {text}
    </button>
    )
}

Button.defaultrops = {
    color: 'steelblue'
}

Button.propTypes = {
    text: PropTypes.string,
    color:PropTypes.string,
    onClick: PropTypes.func,
}

export default Button
