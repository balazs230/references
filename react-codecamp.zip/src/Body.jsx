import React from 'react'

const Body = ({user}) => {
  return (
    <div>
        <h1>Welcome back, {user}!</h1>
    </div>
  )
}

export default Body
