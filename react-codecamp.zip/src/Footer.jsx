import React from 'react'

const Footer = () => {
    return (
      <footer className='footer'>
        &copy;2022 Bacs development. All rights reserved
      </footer>
    )
  }

export default Footer
