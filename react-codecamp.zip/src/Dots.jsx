import React from 'react'

const Dots = () => {
  return (
    <ul>
      <li></li>
      <li></li>
      <li></li>
    </ul>
  )
}

export default Dots
