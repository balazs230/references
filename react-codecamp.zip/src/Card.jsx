import React from 'react'

const Card = (props) => {
    console.log(props)
  return (
    <div className='card'>
        {props.openSpots === 0 && props.location !== 'online'
            ? <div className='card--badge'>SOLD OUT</div>
            : props.location === 'online' && <div className='card--badge'> ONLINE</div>}
        <img src={'./' + props.coverImg} className='card--image' alt='photo'/>
        <div className="card--stats">
            <img src="./Star 1.png" alt="" className='card--star'/>
            <span>{props.stats.rating}</span>
            <span className='gray'>({props.stats.reviewCount}) · </span>
            <span className='gray'>{props.location}</span>
        </div>
        <p>{props.title}</p>
        <p><strong>From ${props.price}</strong> / person</p>
    </div>
  )
}

export default Card
