import React from 'react'

const Box = (props) => {

    let styleOff = {
        backgroundColor: 'gray'
    }
    let styleOn = {
        backgroundColor: 'orangered'
    }

  return (
    <div className='box' style={props.on ? styleOn : styleOff} onClick={props.toggle}></div>
  )
}

export default Box
