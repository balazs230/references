import React from 'react'

const Die = (props) => {
    // const dots = () => {
    //     switch (props.value) {
    //                 case 1:
    //                     return (
    //                     <div className='dots'>
    //                         <span>&#9679;</span>
    //                     </div>
    //                     )
    //                 case 2:
    //                     return (
    //                     <div className='dots'>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                     </div>
    //                     )
    //                 case 3:
    //                     return (
    //                     <div className='dots'>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                     </div>
    //                     )
    //                 case 4:
    //                     return (
    //                     <div className='dots'>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                     </div>
    //                     )
    //                 case 5:
    //                     return (
    //                     <div className='dots'>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                     </div>
    //                     )
    //                 case 6:
    //                     return (
    //                     <div className='dots'>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                         <span>&#9679;</span>
    //                     </div>
    //                     )
    //             }
    // }

    return (
        <div className={`square ${props.isHeld && "held"}`} onClick={props.holdDice}>
            {props.value}
        </div>
    )
}

export default Die

// const dots = () => {
//     switch (props.value) {
//                 case 1:
//                     return (
//                     <img src="https://i.pinimg.com/736x/f4/50/21/f450216324990b23295ee972465f1cfc.jpg" alt="" />
//                     )
//                 case 2:
//                     return (
//                     <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Dice-2-b.svg/1024px-Dice-2-b.svg.png" alt="" />
//                     )
//                 case 3:
//                     return (
//                     <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Dice-3-b.svg/557px-Dice-3-b.svg.png" alt="" />
//                     )
//                 case 4:
//                     return (
//                     <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Dice-4-b.svg/557px-Dice-4-b.svg.png" alt="" />
//                     )
//                 case 5:
//                     return (
//                     <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Quincunx.svg/1024px-Quincunx.svg.png" alt="" />
//                     )
//                 case 6:
//                     return (
//                     <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Dice-6-b.svg/768px-Dice-6-b.svg.png" alt="" />
//                     )
//             }
// }
