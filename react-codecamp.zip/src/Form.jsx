import React, { useState } from 'react'

const Form = () => {
    const [formData, setFormData] = useState({
        user_name: '',
        password: '',
        conf_pass: '',
        newsletter: false,
    });

    function handleChange(event) {
        const { name, value, type, checked } = event.target
        setFormData(prevFormData => {
            return ({
                ...prevFormData,
                [name]: type === 'checkbox' ? checked : value
            })
        })
    }

    function handleSubmit(event) {
        event.preventDefault()
        console.log(formData.password === formData.conf_pass ? 'Successfully signed in!' : 'Passwords don\'t match!')
        formData.newsletter && console.log('Thanks for subscribing to our newsletter!')
    }

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" placeholder='Name' name='user_name' onChange={handleChange} value={formData.user_name} />

            <input type="password" placeholder='Password' name='password' onChange={handleChange} value={formData.password} />

            <input type="password" placeholder='Confirm password' name='conf_pass' onChange={handleChange} value={formData.conf_pass} />

            <br />
            <label htmlFor="isChecked">I want to join the newsletter.</label>
            <input type="checkbox" name="newsletter" id="newsletter" checked={formData.newsletter} onChange={handleChange} />
            <br />
            <button>Sign up</button>

            <h1>Username: {formData.user_name}</h1>
        </form>
    )
}

export default Form
