import React from 'react'

const Count = (props) => {
    return (
        <div className="counter--count" style={{ backgroundColor: `hsl(${props.number}, 50%, 50%)` }}>
            <h1>{props.number}</h1>
        </div>
    )
}

export default Count
