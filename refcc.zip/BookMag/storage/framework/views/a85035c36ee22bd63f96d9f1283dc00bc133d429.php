

<?php $__env->startSection('content'); ?>


    <!-- start left side column -->
    <div class="col-lg-4">
                    
        <!-- start search -->
        <ul class="list-group list-group-flush">
            <li class="list-group-item list-group-item-action active disabled"> Cauta </li>
            <li class="list-group-item list-group-item-action">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search">
                    <div class="input-group-append">
                        <button class="btn btn-info" type="submit">Go</button>
                    </div>
                </div>
            </li>
        </ul>
        <!-- end search -->
        <br /><br />

        <!-- start categories -->
        <div class="list-group list-group-flush">
            <a href="#" class="list-group-item list-group-item-action active disabled"> Categorii </a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <a href="<?php echo e(route('site.showCategoryBooks', ['id'=>$category->id])); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                    <?php echo e($category->category_name); ?>

                    <span class="badge badge-info badge-pill"><?php echo e($category->books()->count()); ?></span>
                </a> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- end categories -->
    </div>
    <!-- end left side column -->

    <!-- start books column -->
    <div class="col-lg-8">

        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
            <div class="row">

                <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                
                <div class="col-md-6">
                    <div class="card">
                        <img class="card-img-top" src="<?php echo e(asset('storage/books/images/' . $col->image)); ?>" style="object-fit: cover;" height="200px">
                        <div class="card-body" style="text-align: center;">
                            <h5 class="card-title"><?php echo e($col->title); ?></h5>
                            <p class="card-text" style="color: red;">
                                <b><?php echo e($col->price); ?></b><sup>00</sup> Lei
                            </p>
                            <a href="<?php echo e(route('books.show', ['book'=>$col->id ])); ?>" class="btn btn-primary btn-block">Vezi detalii</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            <br />
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <br />

        <!-- start pagination -->
        <ul class="pagination justify-content-center">
            <li class="page-item"><a class="page-link" href="">Previous</a></li>
            <li class="page-item"><a class="page-link" href="">1</a></li>
            <li class="page-item"><a class="page-link" href="">2</a></li>
            <li class="page-item"><a class="page-link" href="">3</a></li>
            <li class="page-item"><a class="page-link" href="">Next</a></li>
        </ul>
    </div>
    <!-- end books column -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/site/showCategorybooks.blade.php ENDPATH**/ ?>