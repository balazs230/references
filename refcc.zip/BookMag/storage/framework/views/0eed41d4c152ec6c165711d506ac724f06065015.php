

<?php $__env->startSection('content'); ?>
    
<div class="row">
                
    <div class="col-lg-12">
        
        <div class="table-responsive-sm">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Carte</th>
                        <th>Nume</th>
                        <th>Mesaj</th>
                        <th>Rating</th>
                        <th>Data</th>
                        <th>Acțiuni</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($review->book->title); ?></td>
                        <td><?php echo e($review->name); ?></td>
                        <td><?php echo e($review->text); ?></td>
                        <td><?php echo e($review->rating); ?>★</td>
                        <td><?php echo e($review->created_at); ?></td>
                        <td>
                            <a onclick="event.preventDefault(); document.getElementById('review-delete-<?php echo e($review->id); ?>').submit();" href="<?php echo e(route('reviews.destroy', ['review'=>$review->id ])); ?>"><i class="fas fa-trash-alt text-danger"></i></a>
                                <form action="<?php echo e(route('reviews.destroy', ['review'=>$review->id ])); ?>" method="POST" id="review-delete-<?php echo e($review->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

        <hr>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/reviews_by_book.blade.php ENDPATH**/ ?>