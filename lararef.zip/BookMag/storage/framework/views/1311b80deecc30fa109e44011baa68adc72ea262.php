
Hello,

<br>
<a href="https://laravel.com/docs/8.x/mail">
<h3 style="margin: 20px 0px 50px; color:green">Welcome to our community, <?php echo e($user->name); ?>!</h3>
</a>

<br>

<ul>
    <li>Your email is: <?php echo e($user->email); ?></li>
    <li>Your address is: <?php echo e($user->address); ?></li>
</ul>

<br><br>

<i>Our team wishes you a great day!</i>

<?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/emails/test.blade.php ENDPATH**/ ?>