<h3>Buna ziua, <?php echo e($order->user->name); ?>!</h3>

<p>Prin acest mesaj te anuntam, ca comanda ta cu ID <b>#<?php echo e($order->id); ?></b>, in valoare de <b><?php echo e($order->total_price); ?> lei</b> a fost refuzata.</p>

<p>Pentru mai multe informatii, contacteaza-ne!</p><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/emails/deleteordermail.blade.php ENDPATH**/ ?>