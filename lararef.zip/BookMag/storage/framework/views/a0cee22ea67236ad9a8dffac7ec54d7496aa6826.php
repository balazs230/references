

<?php $__env->startSection('content'); ?>

<h3>Descriere: <?php echo e($book->title); ?></h3>

            <hr>
            <br />

<form action="<?php echo e(route('descriptions.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-lg-12">
            <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
            <div class="form-group">
                <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Adaugă descrierea produsului" 
                rows="12" name="description"><?php if(!empty($book->description)): ?> <?php echo e($book->description->text); ?><?php endif; ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="form-text" style="color: red;"><?php echo e($message); ?></small>                    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Adaugă Descrierea</button>
            <button type="reset" class="btn btn-danger">Sterge</button>
        </div>
    </div>
</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/description-create.blade.php ENDPATH**/ ?>