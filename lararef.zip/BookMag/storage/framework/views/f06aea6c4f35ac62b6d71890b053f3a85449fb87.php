

<?php $__env->startSection('content'); ?>
    
<div class="row">
    <div class="col-lg-12">

        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Adaugă categorie noua</a>

        <br /><br />

        <div class="table-responsive-sm">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Categorie</th>
                        <th>Carti</th>
                        <th>În stoc</th>
                        <th>Acțiuni</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($category->category_name); ?></td>
                        <td><?php echo e($category->books()->count()); ?></td>
                        <td>36</td>
                        <td>
                            <a href="<?php echo e(route('categories.edit', ['category'=>$category->id ])); ?>"><i class="fas fa-pencil-alt text-primary"></i></a> &nbsp;
                            <a onclick="event.preventDefault(); document.getElementById('category-delete-<?php echo e($category->id); ?>').submit();" href="<?php echo e(route('categories.destroy', ['category'=>$category->id ])); ?>"><i class="fas fa-trash-alt text-danger"></i></a>
                                <form action="<?php echo e(route('categories.destroy', ['category'=>$category->id ])); ?>" method="POST" id="category-delete-<?php echo e($category->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>

        <hr>

        <ul class="pagination justify-content-center">
            <li><?php echo e($categories->links()); ?></li>
        </ul>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/categories/index.blade.php ENDPATH**/ ?>