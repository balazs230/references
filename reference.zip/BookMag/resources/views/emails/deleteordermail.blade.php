<h3>Buna ziua, {{ $order->user->name }}!</h3>

<p>Prin acest mesaj te anuntam, ca comanda ta cu ID <b>#{{ $order->id }}</b>, in valoare de <b>{{ $order->total_price }} lei</b> a fost refuzata.</p>

<p>Pentru mai multe informatii, contacteaza-ne!</p>