<h3>Buna ziua, <?php echo e($order->user->name); ?>!</h3>

<p>Ai plasat cu succes o comanda pe site-ul BookMag!</p>

<b>Detaliile comenzii</b> <br><br>

<b>Order ID: </b>#<?php echo e($order->id); ?> <br><br>

<b>Carti:</b> <?php $__currentLoopData = $order->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <i><?php echo e($book->title); ?>; </i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <br><br>

<b>Data: </b> <?php echo e($order->created_at); ?> <br><br>

<b>Total de plata:</b> <?php echo e($order->total_price); ?> lei <br><br>

<p>In curand vei primi notificare despre statusul comenzii.</p><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/emails/placeorder.blade.php ENDPATH**/ ?>