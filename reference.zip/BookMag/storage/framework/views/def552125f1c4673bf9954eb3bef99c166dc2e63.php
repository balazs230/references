

<?php $__env->startSection('content'); ?>

<div class="col-lg-12">

    <br /><br />

    <div class="row">
        <div class="col-md-9">
            <div class="card">
                <div class="card-body">

<?php $total = 0; $totalbooks = 0; ?>
<?php if(session('cart')): ?>

                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nr.</th>
                                <th>Carte</th>
                                <th>Pret Carte</th>
                                <th>Cantitate</th>
                                <th>Pret Total</th>
                                <th>#</th>
                            </tr>
                        </thead>
                        <tbody>


    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total += $details['price'] * $details['quantity']; $totalbooks += $details['quantity']; ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($details['title']); ?></td>
            <td><?php echo e($details['price']); ?> lei</td>
            <td data-th="Quantity"><?php echo e($details['quantity']); ?></td>
            <td data-th="Subtotal" class="text-center"><?php echo e($details['price'] * $details['quantity']); ?> lei</td>      
            <td><button class="btn btn-danger btn-sm remove-from-cart" data-id="<?php echo e($id); ?>">sterge</button></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?> No books added yet.

<?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <dl>
                        <dt>Numar Produse</dt>
                        <dd><?php echo e($totalbooks); ?></dd>
                        <dt>Pret Total</dt>
                        <dd><?php echo e($total); ?></dd>
                    </dl>
                    <hr>

                    <form action="<?php echo e(route('orders.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-block">Plaseaza Comanda</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <br />

    <!-- start card alte oferte -->
    <div class="card">
        <div class="card-header">Alte oferte</div>
        <div class="card-body">
            <div class="row">

                <?php $__currentLoopData = $recommended_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                    <div class="card">
                        <img class="card-img-top" src="<?php echo e(asset('storage/books/images/' . $item->image)); ?>" style="object-fit: cover;" height="200px">
                        <div class="card-body" style="text-align: center;">
                            <h5 class="card-title"><?php echo e($item->title); ?>, <?php echo e($item->author); ?></h5>
                            <p class="card-text" style="color: red;">
                                <b><?php echo e($item->price); ?></b><sup>00</sup> Lei
                            </p>
                            <a href="<?php echo e(route('books.show', ['book'=>$item->id ])); ?>" class="btn btn-primary btn-block">Vezi detalii</a>
                        </div>
                    </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
    <!-- end card alte oferte -->

</div>

<script type="text/javascript">
        $(".remove-from-cart").click(function (e) {
            e.preventDefault();
            var ele = $(this);
            if(confirm("Esti sigur?")) {
                $.ajax({
                    url: '<?php echo e(url('remove-from-cart')); ?>',
                    method: "DELETE",
                    data: {_token: '<?php echo e(csrf_token()); ?>', id: ele.attr("data-id")},
                    success: function (response) {
                        window.location.reload();
                    }
                });
            }
        });
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Balázs\Dokumentumok\Web Design\Laravel\BookMag\resources\views/cart.blade.php ENDPATH**/ ?>